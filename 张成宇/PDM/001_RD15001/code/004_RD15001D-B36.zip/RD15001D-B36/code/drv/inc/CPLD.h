#ifndef __CPLD_H
#define __CPLD_H	 
#include "kernal.h"

VOID CpldInit(VOID);
VOID CpldOn(VOID);
VOID CpldOff(VOID);

#endif


















#ifndef __DRAW_H
#define __DRAW_H


#define LCD_VRAM_BASE_ADDR 	((uint32_t)SDRAM_BASE_ADDR + 0x00100000)

#endif	   


	 
/* */
#ifndef DOWNLOAD_H_
#define DOWNLOAD_H_

#include "lpc_types.h"
#define DFT_DOWNLOAD_ADDR  0x10008000UL

int32_t LoadFromUart( int argc );

#endif

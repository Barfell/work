The stress_tester program opens and closes files at random in an effort to break yaffs.

compile command: make
run command: ./yaffs_tester

command line options:
	-seed [number]		sets the random seed generator to the number.
  

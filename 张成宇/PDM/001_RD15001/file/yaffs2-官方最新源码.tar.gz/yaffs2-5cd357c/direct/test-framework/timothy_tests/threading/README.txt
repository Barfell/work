Created by Timothy Manning <timothy@yaffs.net> on 7/01/11

This test is designed to test the locking ability of yaffs functions.

compile command: make
run command: ./threading


command line arguments are:
	-h   displays the help contents
	-t   sets the number of threads 


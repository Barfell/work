#ifndef __APPSTORAGE_H
#define __APPSTORAGE_H	 
#include "kernal.h"

VOID DataStorage(VOID);

#endif


















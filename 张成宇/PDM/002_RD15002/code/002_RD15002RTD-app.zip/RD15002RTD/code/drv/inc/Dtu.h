#ifndef __DTU_H
#define __DTU_H	 
#include "kernal.h"

VOID DtuInit(VOID);
VOID DtuPwrOn(VOID);
VOID DtuPwrOff(VOID);
VOID DtuOn(VOID);
VOID DtuOff(VOID);
BOOL DetectOnline(VOID);


#endif


















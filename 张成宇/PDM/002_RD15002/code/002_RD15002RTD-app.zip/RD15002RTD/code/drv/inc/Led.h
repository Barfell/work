#ifndef __LED_H
#define __LED_H	 
#include "kernal.h"

VOID LedInit(VOID);
VOID LedOn(VOID);
VOID LedOff(VOID);

#endif


















#ifndef __TEST_H
#define __TEST_H	 
#include "kernal.h"

VOID TestLed(VOID);
VOID TestTimer(VOID);
VOID TestUart1(VOID);
VOID TestUart1Timer(VOID);
VOID TestSST25VF0(VOID);
VOID TestSST25VF0_Storage(VOID);
VOID DtuBoot(VOID);
VOID UartBoot(VOID);
#endif


















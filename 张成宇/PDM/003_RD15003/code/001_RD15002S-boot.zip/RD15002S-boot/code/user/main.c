#include "Test.h"
#include "Serial.h" 
#include "flash.h"
VOID BoardInit(VOID)
{
	USART_InitTypeDef Usart_InitStruct;
	
	UartInit(&Usart_InitStruct, 115200);
	
	UartCreate(USART1, &Usart_InitStruct, FALSE, TRUE);
	
	UartOpen(USART1);
}

STATIC VOID TestProc(VOID)
{
	
//	TestUart1();

}
EXTERN VOID EnterAppProc(VOID);

STATIC VOID AppProc(VOID)
{
//	U32 u32Tick;
//	S32 s32Tick;
//	U16 u16Count;
//	U8 *szData = malloc(MAXSIZE_A + 50);
//	u32Tick = GetTickCount();
//	while(s32Tick < 3000)
//	{
//		s32Tick = GetTickCount() - u32Tick;
//		
//		if(GetQueueLength(pUart1QueueInfo))
//		{
//			s32Tick = GetTickCount() - GetUartReceiveTime(USART1);

//			if(s32Tick > 20)
//			{
//				
//				ReadUsartData(USART1, szData, &u16Count);
//				if(memcmp(szData, "Enter Update\r\n", u16Count) == 0)
//				{
//					free(szData);
//					UartBoot();
//				}
//				
//			}
//		}
//	}
//	
//	EnterAppProc();
	UartBoot();
	
}

int main(void)
{	

	OsInit();
	BoardInit();
	TestProc();
	AppProc();
	return 0;
}


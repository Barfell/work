#ifndef __SYN_H
#define __SYN_H	 
#include "kernal.h"

VOID EtrSynInit(VOID);

U32 GetEtrSynCount(VOID);


#endif


















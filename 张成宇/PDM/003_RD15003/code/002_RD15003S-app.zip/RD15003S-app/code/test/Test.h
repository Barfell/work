#ifndef __TEST_H
#define __TEST_H	 
#include "kernal.h"

VOID TestUart1(VOID);
VOID TestUart2(VOID);
VOID TestUart3(VOID);
VOID TestUart1Timer(VOID);
VOID TestUart2Timer(VOID);
VOID TestUart3Timer(VOID);
VOID TestCrc(VOID);
VOID TestEtrSynProc(VOID);
VOID TestMileageProc(VOID);
#endif


















#include "board.h"

VOID TestUsart1(VOID)
{
    printf("\r\n����1����\r\n");
    while(1)
    {
        if(GetUsartCurrentLength(USART1_TYPE) != 0)
        {
            Usart1_DMA_Send(g_pUsart1_rx_buf, GetUsartCurrentLength(USART1_TYPE));
            ClearUsartCurrentLength(USART1_TYPE);
        }
        
    }
}

VOID TestUsart2(VOID)
{
//    uart2_init(115200, 256, 256);
    
//    printf("\r\n����2����\r\n");
    while(1)
    {
        if(GetUsartCurrentLength(USART2_TYPE) != 0)
        {
            Usart2_DMA_Send(g_pUsart2_rx_buf, GetUsartCurrentLength(USART2_TYPE));
            ClearUsartCurrentLength(USART2_TYPE);
        }
        
    }
//    U16 u16Count;
//    while(1)
//    {
////        Usart2_DMA_Send("test usart2...", 15);
//		u16Count = 15;
//		USART2_Send("test usart2...", &u16Count);
//        DelayMs_Sft(500);
//        
//    }
}


VOID TestUsart3(VOID)
{
    uart3_init(115200, 256, 256);
    
    printf("\r\n����2����\r\n");
    while(1)
    {
        if(GetUsartCurrentLength(USART3_TYPE) != 0)
        {
            Usart3_DMA_Send(g_pUsart3_rx_buf, GetUsartCurrentLength(USART3_TYPE));
            ClearUsartCurrentLength(USART3_TYPE);
        }
        
    }
}

VOID Test3Usart(VOID)
{

    printf("\r\n3���ڲ���\r\n");
    uart1_init(115200, 256, 256);
    uart2_init(115200, 256, 256);
    uart3_init(115200, 256, 256);
    
    while(1)
    {
        Usart1_DMA_Send("test usart1...", 15);
        Usart2_DMA_Send("test usart2...", 15);
        Usart3_DMA_Send("test usart3...", 15);
        DelayMs(100);
        
    }
}

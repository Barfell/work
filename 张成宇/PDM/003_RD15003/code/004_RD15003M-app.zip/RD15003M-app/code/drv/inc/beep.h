#ifndef __BEEP_H
#define __BEEP_H	 
#include "kernal.h"

VOID BeepInit(VOID);
VOID BeepOn(VOID);
VOID BeepOff(VOID);

#endif


















#ifndef __KEY_H
#define __KEY_H	 
#include "kernal.h"




VOID KeyInit(VOID);

#endif


















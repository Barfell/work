#ifndef __LED_H
#define __LED_H	 

#include "kernal.h"

VOID LedInit(VOID);
VOID SysLedOn(VOID);
VOID SysLedOff(VOID);
VOID DatLedOn(VOID);
VOID DatLedOff(VOID);
VOID PwrLedOn(VOID);
VOID PwrLedOff(VOID);

#endif


















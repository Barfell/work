#include "comm.h"

VOID TestCommProc(VOID)
{
}


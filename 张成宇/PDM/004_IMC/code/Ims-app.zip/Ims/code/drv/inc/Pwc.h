#ifndef __LED_H
#define __LED_H	 
#include "kernel.h"

VOID PWCInit(VOID);
VOID PWCOn(VOID);
VOID PWCOff(VOID);
VOID ResetIpc(VOID);

#endif


















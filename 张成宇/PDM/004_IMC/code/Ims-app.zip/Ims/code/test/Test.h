#ifndef __TEST_H
#define __TEST_H	 
#include "kernel.h"

VOID TestUart1(VOID);
VOID TestUart1Timer(VOID);
VOID TestAdc(VOID);

#endif


















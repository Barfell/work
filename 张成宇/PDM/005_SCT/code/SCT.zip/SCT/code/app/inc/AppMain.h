#ifndef __APPSTORAGE_H
#define __APPSTORAGE_H	 
#include "kernel.h"

VOID AppMain(VOID);

#endif


















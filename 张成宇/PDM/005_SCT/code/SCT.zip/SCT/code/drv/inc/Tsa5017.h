#ifndef __TSA5017_H
#define __TSA5017_H	 
#include "kernel.h"

VOID Tsa5017Init(VOID);
VOID Tsa5017_CH1(VOID);
VOID Tsa5017_CH2(VOID);
VOID Tsa5017_CH3(VOID);
VOID Tsa5017_CH4(VOID);
#endif


















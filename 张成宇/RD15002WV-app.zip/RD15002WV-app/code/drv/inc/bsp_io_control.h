#ifndef _BSP_IO_CONTROL_H
#define _BSP_IO_CONTROL_H

#include "kernal.h"

void SW_12V(unsigned char onOroff);

void SW_5V(unsigned char onOroff);

void SW_3V(unsigned char onOroff);

void SW_VW_TRCN(unsigned char onOroff);

void SW_DTU(unsigned char onOroff);

void SW_VW(unsigned char onOroff);

#endif


#ifndef __TOOL_H
#define __TOOL_H

//����
#include "type32.h"
#include "archDef.h"
//C��
#include "stdio.h"
#include "stdlib.h"
#include "string.h"

#endif












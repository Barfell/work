#ifndef __TEST_H
#define __TEST_H

#include "kernal.h"


VOID TestUsart1(VOID);
VOID TestUsart2(VOID);
VOID TestUsart3(VOID);
VOID TestUsart4(VOID);
VOID TestUsartSend(VOID);
VOID TestUsart(VOID);
VOID TestSST25VF0(VOID);
VOID TestSST25VF0_Storage(VOID);
VOID TestRtc(VOID);
VOID TestLtc2402(VOID);
VOID TestDtu(VOID);

#endif


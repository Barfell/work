#ifndef __LED_H
#define __LED_H	 
#include "kernel.h"

VOID LedInit(VOID);
VOID LedOn(VOID);
VOID LedOff(VOID);

#endif


















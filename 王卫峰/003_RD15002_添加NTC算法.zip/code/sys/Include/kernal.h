#ifndef __BSP_H
#define __BSP_H	

//bsp����
#include "stm32f4xx.h" 
#include "stm32f4xx_conf.h"
//���ߵ���
#include "tool.h"
//˽�е���
#include "malloc.h"	 
//ERROR CODE
enum
{
    ERR_RFID_STEP_1 = 1,
    ERR_RFID_STEP_2,
    ERR_RFID_STEP_3,
    ERR_RFID_STEP_4,
    ERR_RFID_STEP_5,
    ERR_RFID_STEP_6,
    ERR_RFID_STEP_7,
    ERR_RFID_STEP_8,
    ERR_RFID_STOP,
    ERR_NAND_BADBLOCK_FULL,
    ERR_NAND_FULL,
    ERR_NAND_MALLOC_FAIL,
    ERR_GPS_NAND_FULL,
    ERR_INS_NAND_FULL,
    ERR_OTHER_NAND_FULL,
    ERR_RFID_NAND_FULL,
    ERR_UPAN_OPEN_FAIL,
    ERR_UPAN_WRITE_FAIL,
    ERR_UPAN_READ_FAIL,
    ERR_UPAN_CLOSE_FAIL,
    ERR_USATT1_MALLOC_FAIL,
    ERR_USATT2_MALLOC_FAIL,
    ERR_USATT3_MALLOC_FAIL,
	ERR_USATT4_MALLOC_FAIL,
    ERR_OTHER_MALLOC_FAIL,
    ERR_OTHER_SPACE_FULL,
    ERR_INS_SPACE_FULL,
    ERR_GPS_SPACE_FULL,
    ERR_COMM_MALLOC_FAIL,
    ERR_TEST_MALLOC_FAIL,
    ERR_SD_WRITE_FAIL,
    ERR_SD_READ_FAIL,    
    ERR_ADD_FAIL,
};
																	    
	 
//λ������
//����ʵ��˼��,�ο�<<CM3Ȩ��ָ��>>������(87ҳ~92ҳ).M4ͬM3����,ֻ�ǼĴ�����ַ����.
//IO�ڲ����궨��
#define BITBAND(addr, bitnum) ((addr & 0xF0000000)+0x2000000+((addr &0xFFFFF)<<5)+(bitnum<<2)) 
#define MEM_ADDR(addr)  *((volatile unsigned long  *)(addr)) 
#define BIT_ADDR(addr, bitnum)   MEM_ADDR(BITBAND(addr, bitnum)) 
//IO�ڵ�ַӳ��
#define GPIOA_ODR_Addr    (GPIOA_BASE+20) //0x40020014
#define GPIOB_ODR_Addr    (GPIOB_BASE+20) //0x40020414 
#define GPIOC_ODR_Addr    (GPIOC_BASE+20) //0x40020814 
#define GPIOD_ODR_Addr    (GPIOD_BASE+20) //0x40020C14 
#define GPIOE_ODR_Addr    (GPIOE_BASE+20) //0x40021014 
#define GPIOF_ODR_Addr    (GPIOF_BASE+20) //0x40021414    
#define GPIOG_ODR_Addr    (GPIOG_BASE+20) //0x40021814   
#define GPIOH_ODR_Addr    (GPIOH_BASE+20) //0x40021C14    
#define GPIOI_ODR_Addr    (GPIOI_BASE+20) //0x40022014     

#define GPIOA_IDR_Addr    (GPIOA_BASE+16) //0x40020010 
#define GPIOB_IDR_Addr    (GPIOB_BASE+16) //0x40020410 
#define GPIOC_IDR_Addr    (GPIOC_BASE+16) //0x40020810 
#define GPIOD_IDR_Addr    (GPIOD_BASE+16) //0x40020C10 
#define GPIOE_IDR_Addr    (GPIOE_BASE+16) //0x40021010 
#define GPIOF_IDR_Addr    (GPIOF_BASE+16) //0x40021410 
#define GPIOG_IDR_Addr    (GPIOG_BASE+16) //0x40021810 
#define GPIOH_IDR_Addr    (GPIOH_BASE+16) //0x40021C10 
#define GPIOI_IDR_Addr    (GPIOI_BASE+16) //0x40022010 
 
//IO�ڲ���,ֻ�Ե�һ��IO��!
//ȷ��n��ֵС��16!
#define PAout(n)   BIT_ADDR(GPIOA_ODR_Addr,n)  //��� 
#define PAin(n)    BIT_ADDR(GPIOA_IDR_Addr,n)  //���� 

#define PBout(n)   BIT_ADDR(GPIOB_ODR_Addr,n)  //��� 
#define PBin(n)    BIT_ADDR(GPIOB_IDR_Addr,n)  //���� 

#define PCout(n)   BIT_ADDR(GPIOC_ODR_Addr,n)  //��� 
#define PCin(n)    BIT_ADDR(GPIOC_IDR_Addr,n)  //���� 

#define PDout(n)   BIT_ADDR(GPIOD_ODR_Addr,n)  //��� 
#define PDin(n)    BIT_ADDR(GPIOD_IDR_Addr,n)  //���� 

#define PEout(n)   BIT_ADDR(GPIOE_ODR_Addr,n)  //��� 
#define PEin(n)    BIT_ADDR(GPIOE_IDR_Addr,n)  //����

#define PFout(n)   BIT_ADDR(GPIOF_ODR_Addr,n)  //��� 
#define PFin(n)    BIT_ADDR(GPIOF_IDR_Addr,n)  //����

#define PGout(n)   BIT_ADDR(GPIOG_ODR_Addr,n)  //��� 
#define PGin(n)    BIT_ADDR(GPIOG_IDR_Addr,n)  //����

#define PHout(n)   BIT_ADDR(GPIOH_ODR_Addr,n)  //��� 
#define PHin(n)    BIT_ADDR(GPIOH_IDR_Addr,n)  //����

#define PIout(n)   BIT_ADDR(GPIOI_ODR_Addr,n)  //��� 
#define PIin(n)    BIT_ADDR(GPIOI_IDR_Addr,n)  //����

//����Ϊ��ຯ��
VOID WFI_SET(VOID);		//ִ��WFIָ��
VOID INTX_DISABLE(VOID);//�ر������ж�
VOID INTX_ENABLE(VOID);	//���������ж�
VOID MSR_MSP(u32 addr);	//���ö�ջ��ַ 

VOID OsInit(VOID);
VOID DelayMs(U32 nTime);
VOID DelayMs_Sft(U32 nTime);
VOID DelayUs_Sft(U32 nTime);
U32 GetTickCount(VOID);
U32 GetSecondOfWeek(VOID);
VOID SetSecondOfWeek(U32 u32Cnt);
VOID EnterException(U32 u32ErrCode);
#endif












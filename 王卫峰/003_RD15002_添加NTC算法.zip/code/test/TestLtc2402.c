#include "spi.h"
#include "kernal.h"
#include "ltc2402.h"
#include "test.h"


void TestLtc2402(void)
{
    u8 u8channel = 1;
    u8 u8count = 0;
    LTC2402Init();
    LTC2402_SWitchInit();
    while(1)
    {
        GetNTCTemperature(LTC2402_GetResistance());
//        u8channel = 1;
        LTC2402_SwitchChannel(u8channel);
//        DelayMs(200);
        printf("Channel %d  ",u8channel);
        
        DelayMs(585);
//        if(u8count == 25)
//        {
////            
//            u8channel++;
//            if (u8channel == 5)
//            {
//                u8channel = 1;
//            }
//            u8count = 0;
//        }
        u8count++;
        u8channel++;
        if(u8channel==5)
        {
            u8channel = 1;
        }
    }
    
}


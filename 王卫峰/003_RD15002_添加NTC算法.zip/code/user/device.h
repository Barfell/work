#ifndef __DEVICE_H
#define __DEVICE_H

#include "usart.h" 
#endif

